import { Project, Skill } from '@/types';

export const skills: Skill[] = [
  // Frontend
  { name: 'React', level: 90, category: 'frontend' },
  { name: 'Next.js', level: 85, category: 'frontend' },
  { name: 'TypeScript', level: 88, category: 'frontend' },
  { name: 'Tailwind CSS', level: 92, category: 'frontend' },
  { name: 'Vue.js', level: 75, category: 'frontend' },
  
  // Backend
  { name: 'Node.js', level: 85, category: 'backend' },
  { name: 'Express.js', level: 80, category: 'backend' },
  { name: 'Python', level: 75, category: 'backend' },
  { name: 'GraphQL', level: 70, category: 'backend' },
  
  // Database
  { name: 'MongoDB', level: 82, category: 'database' },
  { name: 'PostgreSQL', level: 78, category: 'database' },
  { name: 'Redis', level: 65, category: 'database' },
  
  // Tools
  { name: 'Git', level: 90, category: 'tools' },
  { name: 'Docker', level: 70, category: 'tools' },
  { name: 'AWS', level: 65, category: 'tools' },
];

export const projects: Project[] = [
  {
    id: '1',
    title: 'E-Commerce Platform',
    description: 'Plateforme e-commerce complète avec paiement, gestion des stocks et analytics en temps réel.',
    image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=800',
    technologies: ['Next.js', 'TypeScript', 'Stripe', 'MongoDB', 'Tailwind CSS'],
    githubUrl: 'https://github.com/example/ecommerce',
    demoUrl: 'https://demo-ecommerce.com',
    featured: true,
    category: 'fullstack'
  },
  {
    id: '2',
    title: 'Task Management App',
    description: 'Application de gestion de tâches collaborative avec temps réel et notifications.',
    image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800',
    technologies: ['React', 'Node.js', 'Socket.io', 'PostgreSQL', 'Redux'],
    githubUrl: 'https://github.com/example/taskmanager',
    demoUrl: 'https://demo-taskmanager.com',
    featured: true,
    category: 'fullstack'
  },
  {
    id: '3',
    title: 'Weather Dashboard',
    description: 'Dashboard météorologique avec prévisions, cartes interactives et alertes personnalisées.',
    image: 'https://images.pexels.com/photos/1118873/pexels-photo-1118873.jpeg?auto=compress&cs=tinysrgb&w=800',
    technologies: ['Vue.js', 'Chart.js', 'OpenWeather API', 'Sass'],
    githubUrl: 'https://github.com/example/weather',
    demoUrl: 'https://demo-weather.com',
    featured: false,
    category: 'frontend'
  },
  {
    id: '4',
    title: 'API Analytics',
    description: 'Service d\'analyse d\'API avec monitoring, métriques et alertes automatisées.',
    image: 'https://images.pexels.com/photos/590020/pexels-photo-590020.jpeg?auto=compress&cs=tinysrgb&w=800',
    technologies: ['Python', 'FastAPI', 'Redis', 'Grafana', 'Docker'],
    githubUrl: 'https://github.com/example/analytics',
    demoUrl: 'https://demo-analytics.com',
    featured: false,
    category: 'backend'
  }
];