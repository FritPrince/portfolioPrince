import { NextRequest, NextResponse } from 'next/server';
import { ContactMessage } from '@/types';

// Simuler une base de données en mémoire
const messages: ContactMessage[] = [];

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, email, subject, message } = body;

    // Validation basique
    if (!name || !email || !subject || !message) {
      return NextResponse.json(
        { error: 'Tous les champs sont requis' },
        { status: 400 }
      );
    }

    // Créer le message
    const newMessage: ContactMessage = {
      id: Date.now().toString(),
      name,
      email,
      subject,
      message,
      createdAt: new Date(),
      read: false,
    };

    // Ajouter à la "base de données"
    messages.push(newMessage);

    // Ici, vous pourriez ajouter l'envoi d'email
    // await sendEmail(newMessage);

    return NextResponse.json(
      { message: 'Message envoyé avec succès', id: newMessage.id },
      { status: 200 }
    );
  } catch (error) {
    console.error('Erreur lors de l\'envoi du message:', error);
    return NextResponse.json(
      { error: 'Erreur interne du serveur' },
      { status: 500 }
    );
  }
}

export async function GET() {
  // Endpoint pour récupérer tous les messages (pour l'interface admin)
  return NextResponse.json(messages);
}