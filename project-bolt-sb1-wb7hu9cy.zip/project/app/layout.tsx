import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Alexandre Dubois - Développeur Web Fullstack',
  description: 'Portfolio de Alexandre Dubois, développeur web fullstack spécialisé en React, Next.js, Node.js et technologies modernes.',
  keywords: 'développeur web, fullstack, React, Next.js, Node.js, portfolio, freelance',
  authors: [{ name: 'Alexandre Dubois' }],
  creator: 'Alexandre Dubois',
  openGraph: {
    title: 'Alexandre Dubois - Développeur Web Fullstack',
    description: 'Portfolio de Alexandre Dubois, développeur web fullstack spécialisé en React, Next.js, Node.js et technologies modernes.',
    url: 'https://alexandre-dubois.dev',
    siteName: 'Alexandre Dubois Portfolio',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Alexandre Dubois - Développeur Web Fullstack',
    description: 'Portfolio de Alexandre Dubois, développeur web fullstack spécialisé en React, Next.js, Node.js et technologies modernes.',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" className="scroll-smooth">
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}